using Serilog;
using Service;

IHost host = Host.CreateDefaultBuilder(args)
    .ConfigureServices(services =>
    {
        services.AddHostedService<Worker>();
    })
    .Build();

string logsDirectory = Path.Combine(Environment.CurrentDirectory, "logs");

// Configure Serilog pipeline
Log.Logger = new LoggerConfiguration()
   .MinimumLevel.Debug()
   .WriteTo.RollingFile(Path.Combine(logsDirectory, "log-{Date}.txt"))
   .CreateLogger();

await host.RunAsync();
